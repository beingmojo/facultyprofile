<?php

$emailSig="\r\rInstitutional Review Board\r
ospirb@txstate.edu\r
Office of Research Compliance\r
Texas State University-San Marcos\r
(ph) 512/245-2314 / (fax) 512/245-3847\r 
JCK 489\r
601 University Drive\r
San Marcos, TX 78666 \r
Texas State University-San Marcos is a member of the Texas State University System\r\r
NOTE:  This email, including attachments, may include confidential and/or proprietary information and may be used only by the person or entity to which it is addressed.  If the reader of this email is not the intended recipient or his or her agent, the reader is hereby notified that any dissemination, distribution or copying of this email is prohibited.  If you have received this email in error, please notify the sender by replying to this message and deleting this email immediately.  Unless otherwise indicated, all information included within this document and any documents attached should be considered working papers of this office, subject to the laws of the State of Texas. \r"

$irbadd="http://www.osp.txstate.edu/irb_new/index.php";
?>
