<style type="text/css">
<!--
.style2 {
	font-size: x-small;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</style>
    <div align="center">   

  <span class="style2">Office of Research Compliance<br>
For questions regarding application submission, use the  <a href= "http://www.txstate.edu/research/irb/irb_inquiry.html" target="_blank">IRB INQUIRY REQUEST FORM</a> or call IRB administration at x2314
    </span></div>  
