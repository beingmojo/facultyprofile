<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Online Application | Institutional Review Board | Texas State University-San Marcos</title>
<style type="text/css">
<!--
.style4 {
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 40px;
	color: #333399;
}
.style5 {
	color: #333399;
	font-style: italic;
	font-weight: bold;
}
.style6 {
	font-family: Arial, Helvetica, sans-serif;
	color: #333399;
	font-weight: bold;
}
.style7 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #4d3319;
}
a.navbar:link {
	color: #4d3319;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	font-weight: normal;
}
a.navbar:visited {
	color: #4d3319;
	text-decoration: none;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
}
a.navbar:hover {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	text-decoration: underline;
}
a.body:link {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #336699;
	text-decoration: underline;
}
a.body:visited {
	font-family: Arial, Helvetica, sans-serif;
	color: #4D3319;
	text-decoration: underline;
}
.style12 {color: #4d3319; }
.style13 {color: #4D3319}
-->
</style>

</head>

<body text="#000000">
<table width="800" border="1" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" >
</span>
<tr><td class="style3">
<table width="800" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" >
 <tbody>
    <tr>
      <td height="150" valign="top" width="800">
      <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
 <tbody>
          <tr>
            <td valign="top" bgcolor="#330000"><a
 href="http://www.txstate.edu"><img src="txstate_logo2.gif"
 alt="TxState" name="TxState" id="TxState" border="0"></a><br>  </td>
            <td bgcolor="#330000">
              <div class="style5" align="right"><font color="#336699"><br>
              </font></div></td>
            </tr>
          
        <tr>
          <td height="21" colspan="4" valign="top"><div align="center">
            <div align="right" class="style5">
              <div align="center">Institutional Review Board </div>
            </div>
            <span class="style6">Online Application </span></div><hr></td>
        </tr>
        <tr>
          <td height="27" colspan="4" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
        </tr>
            </table></td>
  </tr>
  <tr>
    <td height="332" valign="top">      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr>
          <td height="22" colspan="3" valign="top" bgcolor="#FFFFFF"><div align="center">
            <p class="style6 style8">&nbsp;</p>
            <p class="style6 style8">You have logged out.</p>
            <p align="center">&nbsp;</p>
            <p align="center"> <a href="index.php">Log In to IRB</a> </p>
          </div></td>
        </tr>
        <tr>
         
          <td width="429" rowspan="2" valign="top" class="style6"><p align="center"><br>
          </p>          </td>
        </tr>
       
    </table></td>
  </tr>
  <tr>
    <td height="60" valign="top"><div align="center"><span class="style7"><hr>
        Office of Sponsored Programs<br>
        For questions regarding application submission contact: OSP at <a href="mailto:ospinfo@txstate.edu">ospinfo@txstate.edu</a> , x 2314
      </span>
    </div></td>
  </tr>
</table>
</body>
</html>
