<select name="selectStatus">
                <option selected>Select One</option>
								<option value="Application in Process">Application in Process</option>
	<option value="Application Submitted">New Application Submitted</option>
	        <option value="IRB Admin Requests Applicant to Complete HSP Training">IRB Admin Requests Applicant to Complete HSP Training</option>
				<option value="IRB Admin Requests Revision">IRB Admin Requests Revision</option>
			    <option value="Application Revision Received (In Response to Request made by IRB Admin)">Application Revision Received (In Response to Request made by IRB Admin)</option>
					<option value="Application Submitted to IRB Chairs for Review">Application Submitted to IRB Chairs for Review</option>       
			    <option value="Application Submitted to Reviewers for Review">Application Submitted to Reviewers for Review</option>
				 <option value="IRB Chair Requests Revision">IRB Chair Requests Revision</option>
				 	 <option value="Application Revision Received (In Response to Request Made by IRB Chair)">Application Revision Received (In Response to Request Made by IRB Chair)</option>
			    <option value="Approved">Application Approved</option>
				<option value="Application Approved - Exempt">Application Approved - Exempt</option>
			    <option value="Applicant requested continuation">Applicant requested continuation</option>
						    <option value="Application Discontinued">Application Discontinued</option>
              </select> 
