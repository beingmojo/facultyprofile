 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>IRB Exemption Form</title>


<script language="JavaScript">


</script>

<style type="text/css">
<!--
body {
	background-attachment: fixed;
	background-image:     url(../images/donotprint.gif);
	background-repeat: no-repeat;
	background-position: center 85%;
	background-color: #cccccc;
}
-->
</style>
 <style type="text/css">
<!--
.style6 {
	font-family: Arial, Helvetica, sans-serif;
	color: #333399;
	font-weight: bold;
}
a.navbar:link {
	color: #4d3319;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	font-weight: normal;
}
a.navbar:visited {
	color: #4d3319;
	text-decoration: none;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
}
a.navbar:hover {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	text-decoration: underline;
}
a.body:link {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #336699;
	text-decoration: underline;
}
a.body:visited {
	font-family: Arial, Helvetica, sans-serif;
	color: #4D3319;
	text-decoration: underline;
}

a.irb:link{
font-family: Verdana, Arial, Helvetica, sans-serif;
	
	text-decoration: none;

}
a.irb:visited {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	
	text-decoration: none;
}
-->
  </style>
  <style type="text/css">
<!--
body {
	background-color: #CCCCCC;
}
.style21 {
	color: #000066;
	font-size: 16px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style33 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: small;
	color: #000099;
}
.style38 {font-family: Verdana, Arial, Helvetica, sans-serif; font-weight: bold; font-size: small; }
-->
  </style>



</head>

<body >

<table width="800" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" >
 
    <tr>
      <td height="150" valign="top" width="800">
      <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">

          <tr>
            <td valign="top" bgcolor="#330000"><a
 href="http://www.txstate.edu"><img src="../txstate_logo2.gif"
 alt="TxState" name="TxState" id="TxState" border="0"></a><br>  </td></tr></table>
 <table width="100%"><tr><td>

<p>
<div align="center">
  <p><br />
    </p>
  <p>&nbsp;</p>
  <p>Your Application has been submitted. </p>
</div>
<p align="center">Please write down your application number for future reference.
<p align="center"></td></tr><tr><td>

<hr>
      <div align="center">
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p><span class="style33">Office of Sponsored Programs </span><br>
          <span class="style33"><span class="style33">For questions regarding application submission contact OSP at <a
 href="mailto:mb29@txstate.edu">sn10@txstate.edu</a> , x 2314      </span></p>
      </div></td></tr></span>
      </span>
</table>


</body>


</html>
